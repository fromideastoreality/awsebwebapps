from flask import Flask
app = Flask(__name__)


@app.route('/')
def beanstalk_isawesome():
    return 'Elastic Beanstalk is Awesome!'

if __name__ == '__main__':
    app.run()